<?php
include("Conectar.php");

$id = $_GET['id'];
$cambio = $_GET['cambio'];

$query = "SELECT cantidad FROM productos WHERE id = $id";
$result = mysqli_query($conexion, $query);
$fila = mysqli_fetch_assoc($result);

if ($fila) {
    $nuevaCantidad = $fila['cantidad'] + $cambio;
    if ($nuevaCantidad < 0) $nuevaCantidad = 0; 

    $update = "UPDATE productos SET cantidad = $nuevaCantidad WHERE id = $id";
    mysqli_query($conexion, $update);

    echo json_encode(["success" => true, "nuevaCantidad" => $nuevaCantidad]);
} else {
    echo json_encode(["success" => false, "message" => "Producto no encontrado"]);
}
?>
