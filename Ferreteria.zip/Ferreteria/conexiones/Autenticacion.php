<?php
session_start();

$conexion = new mysqli("localhost", "root", "", "ferreYA3");
if ($conexion->connect_errno) {
    die("Error de conexión: " . $conexion->connect_error);
}

$usu   = trim($_POST['usu'] ?? '');
$clave = $_POST['clave'] ?? '';

if ($usu === '' || $clave === '') {
    header("Location: ../views/Login.php?error=1");
    exit;
}

$stmt = $conexion->prepare("SELECT clave, rol FROM usuarios WHERE usu = ?");
$stmt->bind_param("s", $usu);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $fila = $resultado->fetch_assoc();

    if (password_verify($clave, $fila['clave'])) {
        $_SESSION['usuarios'] = $usu;
        $_SESSION['rol'] = $fila['rol'];

        if ($fila['rol'] === 'admin') {
            header("Location: ../views/Menu.php");
        } else {
            header("Location: ../views/Ventas.php");
        }
        exit;
    }
}

header("Location: ../views/Login.php?error=1");
exit;
