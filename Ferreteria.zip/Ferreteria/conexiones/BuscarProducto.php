<?php
include("Conectar.php");

$buscar = isset($_GET['buscar']) ? trim($_GET['buscar']) : "";

if ($buscar !== "") {
    $stmt = $conexion->prepare("SELECT * FROM inventario WHERE nombre_producto LIKE ?");
    $param = "%$buscar%";
    $stmt->bind_param("s", $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conexion->query("SELECT * FROM inventario");
}

include("TablaProductos.php");
?>
