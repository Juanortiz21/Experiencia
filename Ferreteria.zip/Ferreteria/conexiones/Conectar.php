<?php
$conexion = mysqli_connect("localhost", "root", "", "ferreYA3");

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>
