<?php
session_start();

$conexion= new mysqli("localhost","root","","ferreYA3");

if(session_status() === PHP_SESSION_NONE){
    session_start();
}

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo "acceso no permitido";
    exit;
}

$nombre   = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$usu      = trim($_POST['usu'] ?? '');
$correo   = trim($_POST['correo'] ?? '');
$clave    = $_POST['clave'] ?? '';
$repetir  = $_POST['repetir'] ?? '';

if ($nombre === '' || $apellido === '' || $usu === '' || $correo === '' || $clave === '' || $repetir === '') {
    die("⚠️ Todos los campos son obligatorios. <a href='../views/Registro.php'>Volver</a>");
}

if ($clave !== $repetir) {
    echo "Las contraseñas no coinciden. <a href='../views/Registro.php'>Volver</a>";
    exit;
}

if (!preg_match('/^[A-Za-z0-9_]{4,10}$/', $usu)) {
    die("⚠️ El nombre de usuario debe tener entre 4 y 10 caracteres y solo puede contener letras, números y guiones bajos. <a href='../views/Registro.php'>Volver</a>");
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    die("⚠️ El correo electrónico no es válido. <a href='../views/Registro.php'>Volver</a>");
}

if (strlen($clave) < 8 ||
    !preg_match('/[A-Z]/', $clave) ||
    !preg_match('/[a-z]/', $clave) ||
    !preg_match('/[0-9]/', $clave)) {
    die("⚠️ La contraseña debe tener al menos 8 caracteres e incluir mayúsculas, minúsculas y números <a href='../views/Registro.php'>Volver</a>");
}


$stmt = $conexion->prepare("SELECT id FROM usuarios WHERE usu = ? OR correo = ?");
$stmt->bind_param("ss", $usu, $correo);
$stmt->execute();
$resultado = $stmt->get_result();
if ($resultado->num_rows > 0) {
    die("⚠️ El nombre de usuario o correo ya están registrados. <a href='../views/Registro.php'>Volver</a>");
}
$stmt->close();


$clave_hash = password_hash($clave, PASSWORD_DEFAULT);

$stmt = $conexion->prepare("INSERT INTO usuarios (nombre, apellido, usu, correo, clave, rol) VALUES (?, ?, ?, ?, ?, 'usuario')");
$stmt->bind_param("sssss", $nombre, $apellido, $usu, $correo, $clave_hash);

if ($stmt->execute()) {
    echo "<p style='color:green;'>✅ Registro exitoso.</p>";
    echo "<a href='../views/Login.php'>Ir al inicio</a>";
} else {
    echo "<p style='color:red;'>❌ Error al insertar: " . htmlspecialchars($conexion->error) . "</p>";
    echo "<a href='../views/Registro.php'>Volver</a>";
}

$stmt->close();
$conexion->close();
?>