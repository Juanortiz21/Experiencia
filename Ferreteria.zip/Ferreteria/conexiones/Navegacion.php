  <?php

    if (isset($_GET['opcion'])) {
        $opcion = $_GET['opcion'];
        if ($opcion === 'disponibles') {
            header("Location: ../views/Inventario.php");
            exit;
        } elseif ($opcion === 'vendidos') {
            header("Location: ../views/Vendidos.php");
            exit;
        }elseif ($opcion === 'ventas') {
            header("Location: ../views/Ventas.php");
            exit;
        }
    }
    ?>