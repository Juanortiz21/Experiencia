<?php
include("Conectar.php"); 




$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['resetear'])) {
    $conexion->query("DELETE FROM ventas");
    $mensaje = "<p style='color:red;'>⚠️ Todos los registros de ventas han sido eliminados.</p>";
}

$result = $conexion->query("SELECT * FROM ventas ORDER BY fecha_venta DESC");

$total_dinero = 0;
$totales_por_producto = [];

while ($row = $result->fetch_assoc()) {
    $total_dinero += $row['total'];

    if (!isset($totales_por_producto[$row['nombre_producto']])) {
        $totales_por_producto[$row['nombre_producto']] = [
            'cantidad' => 0,
            'valor' => 0
        ];
    }

    $totales_por_producto[$row['nombre_producto']]['cantidad'] += $row['cantidad_vendida'];
    $totales_por_producto[$row['nombre_producto']]['valor'] += $row['total'];

    $ventas[] = $row;
}
?>