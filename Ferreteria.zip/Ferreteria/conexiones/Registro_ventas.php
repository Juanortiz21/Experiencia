<?php
include("Conectar.php"); 


if (!isset($_SESSION['total_acumulado'])) {
    $_SESSION['total_acumulado'] = 0;
}
if (!isset($_SESSION['ventas_actuales'])) {
    $_SESSION['ventas_actuales'] = [];
}

$mensaje = ""; 

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reiniciar'])) {
    $_SESSION['total_acumulado'] = 0;
    $_SESSION['ventas_actuales'] = [];
    $mensaje = "<p style='color:blue;'>🔄 Se ha iniciado una nueva venta. El total acumulado fue reiniciado.</p>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['vender'])) {
    $producto_id = intval($_POST['producto_id']);
    $cantidad_vendida = intval($_POST['cantidad_vendida']);

    $sql = "SELECT * FROM inventario WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $producto = $resultado->fetch_assoc();

    if ($producto && $producto['cantidad'] >= $cantidad_vendida && $cantidad_vendida > 0) {
        $nuevo_stock = $producto['cantidad'] - $cantidad_vendida;
        $total = $producto['precio'] * $cantidad_vendida;

        $update = $conexion->prepare("UPDATE inventario SET cantidad = ? WHERE id = ?");
        $update->bind_param("ii", $nuevo_stock, $producto_id);
        $update->execute();

        $insert = $conexion->prepare("INSERT INTO ventas (producto_id, nombre_producto, cantidad_vendida, precio_unitario, total)
                                  VALUES (?, ?, ?, ?, ?)");
        $insert->bind_param("isidd", $producto_id, $producto['nombre_producto'], $cantidad_vendida, $producto['precio'], $total);
        $insert->execute();

        $_SESSION['ventas_actuales'][] = [
            'nombre' => $producto['nombre_producto'],
            'cantidad' => $cantidad_vendida,
            'precio' => $producto['precio'],
            'total' => $total
        ];

        $_SESSION['total_acumulado'] += $total;

        $mensaje = "<p style='color:green;'>✅ Venta registrada correctamente.</p>";
    } else {
        $mensaje = "<p style='color:red;'>❌ Error: cantidad inválida o producto sin stock suficiente.</p>";
    }
}

$result = $conexion->query("SELECT * FROM inventario");

?>