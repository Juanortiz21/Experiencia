<table border="1" cellpadding="8">
    <tr>
        <th>ID</th>
        <th>Producto</th>
        <th>Descripción</th>
        <th>Precio</th>
        <th>Cantidad disponible</th>
        <th>Imagen</th>
        <th>Acción</th>
    </tr>

    <?php if ($result && $result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['nombre_producto']) ?></td>
                <td><?= htmlspecialchars($row['descripcion']) ?></td>
                <td>$<?= number_format($row['precio'], 2) ?></td>
                <td><?= $row['cantidad'] ?></td>
                <td>
                    <?php
                    if (!empty($row['imagen'])) {
                        $nombreImagen = basename($row['imagen']);
                        $rutaWeb = "../imagenes/" . $nombreImagen;
                        echo "<img src='$rutaWeb' width='100' height='100' alt='Imagen del producto'>";
                    } else {
                        echo "<span style='color:gray;'>Sin imagen</span>";
                    }
                    ?>
                </td>
                <td>
                    <form method="POST" action="">
                        <input type="hidden" name="producto_id" value="<?= $row['id'] ?>">
                        <input type="number" name="cantidad_vendida" min="1" max="<?= $row['cantidad'] ?>" required>
                        <input type="submit" name="vender" value="Vender">
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="7" style="text-align:center;">No se encontraron productos.</td></tr>
    <?php endif; ?>
</table>
