$(document).ready(function() {
    
        $("#buscar").on("keyup", function() {
            let valor = $(this).val().trim();
            $.ajax({
                url: "../conexiones/BuscarProducto.php",
                type: "GET",
                data: { buscar: valor },
                success: function(data) {
                    $("#tablaProductos").html(data);
                }
            });
        });
    });