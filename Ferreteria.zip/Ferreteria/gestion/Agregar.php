<?php

if (isset($_POST['agregar'])) {
    $nombre = trim($_POST['nombre']);
    $descripcion = trim($_POST['descripcion']);
    $cantidad = intval($_POST['cantidad']);
    $precio = floatval($_POST['precio']);
    $imagen = null;

    if (!empty($_FILES['imagen']['name'])) {
        $nombreImagen = basename($_FILES['imagen']['name']);
        $rutaDestino = "../imagenes/" . $nombreImagen;
        $tipo = strtolower(pathinfo($rutaDestino, PATHINFO_EXTENSION));

        $formatosPermitidos = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($tipo, $formatosPermitidos)) {
            if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
                $imagen = $nombreImagen;
            }
        }
    }

    $sql = "INSERT INTO inventario (nombre_producto, descripcion, cantidad, precio, imagen) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "ssids", $nombre, $descripcion, $cantidad, $precio, $imagen);
    mysqli_stmt_execute($stmt);
    header("Location: Inventario.php");
    exit;
}

if (isset($_GET['accion']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $accion = $_GET['accion'];

    if ($accion === 'aumentar') {
        $sql = "UPDATE inventario SET cantidad = cantidad + 1 WHERE id = $id";
    } elseif ($accion === 'disminuir') {
        $sql = "UPDATE inventario SET cantidad = GREATEST(cantidad - 1, 0) WHERE id = $id";
    }

    mysqli_query($conexion, $sql);
    header("Location: ../views/Inventario.php");
    exit;
}

$resultado = mysqli_query($conexion, "SELECT * FROM inventario");
?>