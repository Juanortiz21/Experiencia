<?php

header("Location: views/Login.php");
exit;
