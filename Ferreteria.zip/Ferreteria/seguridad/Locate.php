<?php
session_start();
if (!isset($_SESSION['usuarios'])) {
    header("Location: Login.php");
    exit;
}