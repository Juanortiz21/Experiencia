<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuarios'])) {
    header("Location: ../views/Login.php");
    exit;
}

$rol = $_SESSION['rol'] ?? 'usuario';
$archivo_actual = basename($_SERVER['PHP_SELF']);

$permisos = [
    'admin' => ['Menu.php', 'Inventario.php', 'Ventas.php', 'Vendidos.php'],
    'usuario' => ['Ventas.php', 'Menu.php']
];

if (!in_array($archivo_actual, $permisos[$rol])) {
    echo "<h2 style='color:red;'>🚫 No tienes permiso para acceder a esta página</h2>";
    echo "<a href='../views/Menu.php'>Ir al Menu</a>";
    exit;
}
?>
