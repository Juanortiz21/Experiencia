<?php
$hash = password_hash("12345", PASSWORD_DEFAULT);
echo "Tu nuevo hash es:<br><br>";
echo "<strong>$hash</strong>";
