<?php 
include("../seguridad/Locate.php");
include("../conexiones/Conectar.php"); 
include("../gestion/Agregar.php");
include("../seguridad/Verificacion.php"); 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>INVENTARIO</title>
    <link rel="stylesheet" href="../css/Inventario.css">
</head>
<body>

    <header>
         <img src="../logos/logofi.png" alt="Logo FerreYA" class="logo">
    </header>
    
    <h1>INVENTARIO</h1>

    <h2>Agregar productos</h2>
    <form action="Inventario.php" method="POST" enctype="multipart/form-data">
        <label>Nombre del producto:</label>
        <input type="text" name="nombre" required>

        <label>Descripción:</label>
        <textarea name="descripcion" rows="3"></textarea>

        <label>Cantidad:</label>
        <input type="number" name="cantidad" min="0" required>

        <label>Precio por unidad:</label>
        <input type="number" step="0.01" name="precio" required>

        <label>Imagen:</label>
        <input type="file" name="imagen" accept="image/*">

        <input type="submit" name="agregar" value="Agregar producto">
    </form>

    <hr>

    <h2>Productos Disponibles</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Imagen</th>
            <th>Producto</th>
            <th>Descripción</th>
            <th>Cantidad</th>
            <th>Precio</th>
            <th>Acciones</th>
        </tr>

        <?php while ($fila = mysqli_fetch_assoc($resultado)) { ?>
            <tr>
                <td><?php echo $fila['id']; ?></td>
                <td>
                    <?php if ($fila['imagen']) { ?>
                        <img src="../imagenes/<?php echo htmlspecialchars($fila['imagen']); ?>" width="80" height="80">
                    <?php } else { ?>
                        <span>Sin imagen</span>
                    <?php } ?>
                </td>
                <td><?php echo htmlspecialchars($fila['nombre_producto']); ?></td>
                <td><?php echo htmlspecialchars($fila['descripcion']); ?></td>
                <td><?php echo $fila['cantidad']; ?></td>
                <td>$<?php echo number_format($fila['precio'], 2); ?></td>
                <td>
                    <a href="Inventario.php?accion=aumentar&id=<?php echo $fila['id']; ?>">➕</a>
                    <a href="Inventario.php?accion=disminuir&id=<?php echo $fila['id']; ?>">➖</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <form action="Menu.php" method="GET">
        <input type="submit" value="Atras">
    </form>

</body>
</html>
