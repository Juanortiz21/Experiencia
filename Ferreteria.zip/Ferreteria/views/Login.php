<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>LOGIN - FerreYA</title>
     <link rel="stylesheet" href="../css/Login.css">
</head>
<body>
    <header>
        <img src="../logos/logofi.png" alt="Logo FerreYA" class="logo">
    </header>
    <div class="login-container">
        <h1>Iniciar Sesión</h1>

        <?php if (isset($_GET['error'])): ?>
            <p style="color:red;">Usuario o contraseña incorrectos</p>
        <?php endif; ?>

        <form action="../conexiones/Autenticacion.php" method="POST">
            <label>Usuario:</label><br>
            <input type="text" name="usu" required><br><br>

            <label>Contraseña:</label><br>
            <input type="password" name="clave" required><br><br>

            <input type="submit" value="Iniciar sesión">
        </form>

        <br>
        <form action="Registro.php" method="GET">
            <input type="submit" value="Registrarse">
        </form>
    </div>
</body>
</html>




