<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú - FerreYA</title>
    <link rel="stylesheet" href="../css/Menu.css">
</head>
<body>
    <header>
         <img src="../logos/logofi.png" alt="Logo FerreYA" class="logo">
    </header>
    
    <h1>Calidad Y utilidad en tus manos</h1>

    <main>
        <div class="menu-card">
            <form method="get" action="">
                <label for="opciones"><h2>Opciones</h2></label>
                <select name="opcion" id="opciones" onchange="this.form.submit()">
                    <option value="">-- Seleccionar --</option>
                    <option value="disponibles">Inventario</option>
                    <option value="vendidos">Registro</option>
                    <option value="ventas">Vender</option>
                </select>
            </form>

            <form action="../conexiones/Cerrar.php" method="POST">
                <input type="submit" value="Cerrar sesión" class="cerrar-sesion">
            </form>
        </div>
    </main>
    <?php include "../conexiones/Navegacion.php"; ?>
    <footer>
        © 2025 FerreYA | Sistema de Ferretería
    </footer>
</body>
</html>


 