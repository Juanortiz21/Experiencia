<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="../css/Registro.css">
</head>
<body>
    <header>
        <img src="../logos/logofi.png" alt="Logo FerreYA" class="logo">
    </header>
    <div class="registro-container">
        <h1>Registro</h1>
        <form action="../conexiones/Insertar.php" method="POST">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" pattern="[A-Za-z0-9_]{4,10}+ (?:\s+[A-Za-z0-9_]{4,10}+)*$" required><br><br>

            <label>Apellido</label><br>
            <input type="text" name="apellido" pattern="[A-Za-z0-9_]{4,10}+ (?:\s+[A-Za-z0-9_]{4,10}+)*$" required><br><br>

            <label>Usuario:</label><br>
            <input type="text" name="usu" pattern="[A-Za-z0-9_]{4,10}" required><br><br>

            <label>Correo:</label><br>
            <input type="email" name="correo" required><br><br>

            <label>Contraseña:</label><br>
            <input type="password" name="clave" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}" required><br><br>

            <label>Repetir contraseña:</label><br>
            <input type="password" name="repetir" required><br><br>

            <div class="botones">
                <button type="button" onclick="window.location.href='Login.php'">Ir a login</button>
                <input type="submit" value="Registrarse">
            </div>
        </form>        

</body>
</html>