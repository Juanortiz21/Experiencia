<?php
include("../seguridad/Locate.php");
include("../conexiones/Registro_total.php"); 
include("../seguridad/Verificacion.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Vendidos-FerreYA</title>
    <link rel="stylesheet" href="../css/Vendidos.css">

</head>
<body>
    <header>
         <img src="../logos/logofi.png" alt="Logo FerreYA" class="logo">
    </header>
    <h1>Productos Vendidos-FerreYA</h1>


    <?= $mensaje ?>

    <h2> Historial de Ventas</h2>
    <table border="1" cellpadding="8">
        <tr style="background-color: #f0f0f0;">
            <th>Nombre del Producto</th>
            <th>Cantidad Vendida</th>
            <th>Precio Unitario</th>
            <th>Valor Total</th>
            <th>Fecha de Venta</th>
        </tr>

        <?php if (!empty($ventas)): ?>
            <?php foreach ($ventas as $v): ?>
                <tr>
                    <td><?= htmlspecialchars($v['nombre_producto']) ?></td>
                    <td><?= $v['cantidad_vendida'] ?></td>
                    <td>$<?= number_format($v['precio_unitario'], 2) ?></td>
                    <td>$<?= number_format($v['total'], 2) ?></td>
                    <td><?= $v['fecha_venta'] ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="5" align="center">No hay registros de ventas.</td></tr>
        <?php endif; ?>
    </table>

    <br>

    <h2>Resumen por Producto</h2>
    <table border="1" cellpadding="8">
        <tr style="background-color:#e0e0e0;">
            <th>Producto</th>
            <th>Cantidad Total Vendida</th>
            <th>Valor Total Vendido</th>
        </tr>
        <?php if (!empty($totales_por_producto)): ?>
            <?php foreach ($totales_por_producto as $nombre => $datos): ?>
                <tr>
                    <td><?= htmlspecialchars($nombre) ?></td>
                    <td><?= $datos['cantidad'] ?></td>
                    <td>$<?= number_format($datos['valor'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="3" align="center">No hay ventas registradas.</td></tr>
        <?php endif; ?>
    </table>

    <br>

    
    <h2>Total Acumulado: $<?= number_format($total_dinero, 2) ?> pesos</h2>

    <br>
    
    
<div class="botones">
     <form method="POST" action="" class="form-resetear">
        <input type="submit" name="resetear" value="Borrar registros" class="btn-resetear">
    </form>

    <form action="Menu.php" method="GET" class="form-atras">
        <input type="submit" value="Atrás" class="btn-atras">
    </form>
</div>

   

</body>
</html>

<?php
$conexion->close();
?>
