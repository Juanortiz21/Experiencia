<?php 
include("../seguridad/Locate.php");
include("../conexiones/Registro_ventas.php"); 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ventas - FerreYA</title>

    <link rel="stylesheet" href="../css/Ventas.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../gestion/AJAX.js"></script>
</head>
<body>
    <header>
         <img src="../logos/logofi.png" alt="Logo FerreYA" class="logo">
    </header>
    <h1>Ventas - FerreYA</h1>

    <?= $mensaje ?>

    <?php if (!empty($_SESSION['ventas_actuales'])): ?>
        <h3>🛒 Ventas realizadas en esta sesión:</h3>
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['ventas_actuales'] as $venta): ?>
                    <tr>
                        <td><?= htmlspecialchars($venta['nombre']) ?></td>
                        <td><?= $venta['cantidad'] ?></td>
                        <td>$<?= number_format($venta['precio'], 2) ?></td>
                        <td>$<?= number_format($venta['total'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <h3>Total de compra: $<?= number_format($_SESSION['total_acumulado'], 2) ?></h3>

    <form method="POST" action="">
        <input type="submit" name="reiniciar" value="Reiniciar">
    </form>

    <hr>

    <form onsubmit="return false;">
        <label for="buscar">Buscar producto por nombre:</label>
        <input type="text" name="buscar" id="buscar" placeholder="Ej: martillo, clavo, pintura...">
    </form>

    <br>

    <div id="tablaProductos">
        <?php
        $result = $conexion->query("SELECT * FROM inventario");
        include("../conexiones/TablaProductos.php");
        ?>
    </div>

    <br><br>

    <form action="Menu.php" method="GET">
        <input type="submit" value="Atrás">
    </form>

</body>
</html>

<?php
$conexion->close();
?>
