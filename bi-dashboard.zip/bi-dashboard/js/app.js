import { inicializarFormulario } from './registro.js';
import { inicializarBusqueda } from './buscarEliminar.js';
import { inicializarListado } from './listar.js';

document.addEventListener('DOMContentLoaded', () => {
  inicializarFormulario();
  inicializarBusqueda();
  inicializarListado();
});
