export function inicializarBusqueda() {
  const inputBuscar = document.getElementById('buscar');
  const contenedorResultados = document.getElementById('resultados');
  const detallePaciente = document.getElementById('detalle-paciente');

  inputBuscar.addEventListener('input', async () => {
    const query = inputBuscar.value.trim();
    if (query.length < 1) {
      contenedorResultados.style.display = 'none';
      return;
    }

    try {
      const respuesta = await fetch(`http://localhost:3000/buscar?q=${encodeURIComponent(query)}`);
      const pacientes = await respuesta.json();

      contenedorResultados.innerHTML = '';
      if (pacientes.length > 0) {
        contenedorResultados.style.display = 'block';
        pacientes.forEach(p => {
          const div = document.createElement('div');
          div.textContent = `${p.nombre} (${p.documento.tipo} ${p.documento.numero})`;
          div.classList.add('paciente-item');
          div.onclick = () => mostrarDetalle(p);
          contenedorResultados.appendChild(div);
        });
      } else {
        contenedorResultados.style.display = 'block';
        contenedorResultados.innerHTML = '<em>No se encontraron pacientes.</em>';
      }

    } catch (error) {
      console.error('Error en la búsqueda:', error);
    }
  });

  function mostrarDetalle(paciente) {
    contenedorResultados.style.display = 'none';
    detallePaciente.innerHTML = `
      <h3>Detalles del Paciente</h3>
      <p><strong>Nombre:</strong> ${paciente.nombre}</p>
      <p><strong>Documento:</strong> ${paciente.documento.tipo} ${paciente.documento.numero}</p>
      <p><strong>Edad:</strong> ${paciente.edad}</p>
      <p><strong>Género:</strong> ${paciente.genero}</p>
      <p><strong>Enfermedad:</strong> ${paciente.enfermedad}</p>
      <button id="btnEliminar"> Eliminar Paciente</button>
    `;

    document.getElementById('btnEliminar').onclick = async () => {
      if (confirm(`¿Seguro que deseas eliminar a ${paciente.nombre}?`)) {
        try {
          const resp = await fetch(`http://localhost:3000/eliminar/${paciente.id}`, {
            method: 'DELETE'
          });
          const data = await resp.json();
          alert(data.mensaje);
          detallePaciente.innerHTML = '';
          inputBuscar.value = '';
        } catch (error) {
          console.error('Error al eliminar:', error);
          alert('Error al eliminar paciente.');
        }
      }
    };
  }
}
