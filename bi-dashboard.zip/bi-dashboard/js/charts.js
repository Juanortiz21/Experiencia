
let chartEnf = null; 

async function obtenerDatosGraficas() {
  try {
    const res = await fetch('http://localhost:3000/estadisticas');
    if (!res.ok) throw new Error(`Error HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error('❌ Error al cargar datos de estadísticas:', err);
    return {};
  }
}

async function renderizarGraficas() {
  const datos = await obtenerDatosGraficas();


  const ctx1 = document.getElementById('graficaEdad').getContext('2d');
  new Chart(ctx1, {
    type: 'pie',
    data: {
      labels: ['Menores de edad', 'Mayores de edad'],
      datasets: [{
        data: [datos.menores || 0, datos.mayores || 0],
        backgroundColor: ['#36A2EB', '#FF6384']
      }]
    },
    options: {
      plugins: { legend: { position: 'bottom' } }
    }
  });


  const ctx2 = document.getElementById('graficaEnfermedades').getContext('2d');
  const enfermedadesRaw = datos.enfermedades || {};

  const enfermedades = {};
  for (const [clave, valor] of Object.entries(enfermedadesRaw)) {
    if (!clave) continue;
    const key = clave.trim().toLowerCase();
    enfermedades[key] = (enfermedades[key] || 0) + Number(valor || 0);
  }

  const labels = Object.keys(enfermedades).map(k => k.charAt(0).toUpperCase() + k.slice(1));
  const valores = Object.values(enfermedades);


  if (chartEnf) {
    chartEnf.destroy();
  }

  new Chart(ctx2, {
  type: 'bar',
  data: {
    labels: Object.keys(enfermedades),
    datasets: [{
      label: 'Cantidad de pacientes',
      data: Object.values(enfermedades),
      backgroundColor: Object.keys(enfermedades).map((_, i) =>
        `hsl(${(i * 60) % 360}, 70%, 60%)`
      )
    }]
  },
  options: {
    plugins: {
      legend: { position: 'top' },
      title: {
        display: true,
        text: 'Distribución de Enfermedades'
      }
    },
    scales: {
      y: { beginAtZero: true }
    }
  }
});

  const ctx3 = document.getElementById('graficaLugares').getContext('2d');
  const lugares = datos.lugares || {};

  new Chart(ctx3, {
    type: 'bar',
    data: {
      labels: Object.keys(lugares),
      datasets: [{
        label: 'Pacientes por ciudad',
        data: Object.values(lugares),
        backgroundColor: Object.keys(lugares).map((_, i) => `hsl(${(i * 40 + 120) % 360}, 65%, 60%)`)
      }]
    },
    options: {
      indexAxis: 'y',
      scales: { x: { beginAtZero: true } },
      plugins: {
        legend: {
          labels: { color: '#222', font: { size: 14 } }
        },
        title: {
          display: true,
          text: 'Lugares de Nacimiento',
          color: '#111',
          font: { size: 18, weight: 'bold' }
        }
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', renderizarGraficas);
