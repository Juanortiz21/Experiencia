
async function fetchEstadisticas() {
  const url = 'http://localhost:3000/estadisticas';
  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    return data;
  } catch (err) {
    console.error('Error fetching /estadisticas:', err);
    throw err;
  }
}

export async function cargarEstadisticas() {
  try {
    const datos = await fetchEstadisticas();


    let container = document.getElementById('estadisticasContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'estadisticasContainer';
      container.style.display = 'flex';
      container.style.gap = '20px';
      container.style.flexWrap = 'wrap';
      container.style.marginTop = '20px';
      document.body.appendChild(container);
    }

    container.innerHTML = '';

    const cards = [
      { titulo: 'Total de Pacientes', valor: datos.totalPacientes ?? '0' },
      { titulo: 'Edad Promedio', valor: datos.edadPromedio ?? '0' }
    ];

    cards.forEach(c => {
      const card = document.createElement('div');
      card.style.background = '#f8f9fa';
      card.style.border = '1px solid #ddd';
      card.style.borderRadius = '12px';
      card.style.padding = '20px';
      card.style.boxShadow = '0 2px 5px rgba(0,0,0,0.1)';
      card.style.flex = '1';
      card.style.minWidth = '180px';
      card.style.textAlign = 'center';
      card.innerHTML = `
        <h3 style="margin:0; font-size:18px; color:#333;">${c.titulo}</h3>
        <p style="font-size:32px; font-weight:bold; color:#007bff; margin:10px 0 0;">${c.valor}</p>
      `;
      container.appendChild(card);
    });

  } catch (error) {
    console.error('Error al obtener estadísticas:', error);
    const cont = document.getElementById('estadisticasContainer') || document.body;
    cont.innerHTML = `<p style="color:red;">Error al cargar estadísticas</p>`;
  }
}


document.addEventListener('DOMContentLoaded', () => {
  cargarEstadisticas();
});
