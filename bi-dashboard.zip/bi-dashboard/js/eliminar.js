
const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();

const archivoJSON = path.join(__dirname, '../db.json');

router.delete('/eliminar/:id', (req, res) => {
  const id = req.params.id;

  fs.readFile(archivoJSON, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Error al leer datos' });

    let jsonData;
    try {
      jsonData = JSON.parse(data);
    } catch {
      return res.status(500).json({ error: 'Error al parsear JSON' });
    }

    const index = jsonData.pacientes.findIndex(p => p.id === id);

    if (index === -1) {
      return res.status(404).json({ error: 'Paciente no encontrado' });
    }

    jsonData.pacientes.splice(index, 1);

    fs.writeFile(archivoJSON, JSON.stringify(jsonData, null, 2), err => {
      if (err) return res.status(500).json({ error: 'Error al guardar cambios' });
      res.json({ mensaje: 'Paciente eliminado correctamente 🗑️' });
    });
  });
});

module.exports = router;
