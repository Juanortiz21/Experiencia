
export function inicializarListado() {
  const boton = document.getElementById('mostrarPacientes');
  const contenedor = document.getElementById('listaPacientes');

  boton.addEventListener('click', async () => {
    try {
      const respuesta = await fetch('http://localhost:3000/pacientes');
      if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);

      const pacientes = await respuesta.json();

      if (!pacientes.length) {
        contenedor.innerHTML = '<p>No hay pacientes registrados.</p>';
        return;
      }

      contenedor.innerHTML = `
        <ul>
          ${pacientes
            .map(p => `<li><strong>${p.nombre}</strong> — ${p.enfermedad}</li>`)
            .join('')}
        </ul>
      `;
    } catch (error) {
      console.error('Error al obtener pacientes:', error);
      contenedor.innerHTML = '<p>Error al cargar los pacientes.</p>';
    }
  });
}
