
export function inicializarFormulario() {
  const formulario = document.getElementById('formulario');

  formulario.addEventListener('submit', async (e) => {
    e.preventDefault();

    const paciente = {
      nombre: document.getElementById('nombre').value,
      documento: {                                
        tipo: document.getElementById('tipoDoc').value,
        numero: document.getElementById('numDoc').value
      },
      fechaNacimiento: document.getElementById('fecha').value, 
      edad: document.getElementById('edad').value,
      genero: document.getElementById('sexo').value,
      nacimiento: document.getElementById('ciudad-nacimiento').value, 
      contacto : {
        cel: document.getElementById('cel').value,
        correo: document.getElementById('correo').value,
        direccion: document.getElementById('dir').value
      },
      enfermedad: document.getElementById('enfermedad').value
    };

    try {
      const respuesta = await fetch('http://localhost:3000/registrar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paciente)
      });

      const data = await respuesta.json();
      alert(data.mensaje);
      formulario.reset();

    } catch (error) {
      console.error('Error al registrar paciente:', error);
      alert('Ocurrió un error al registrar el paciente.');
    }
  });
}
