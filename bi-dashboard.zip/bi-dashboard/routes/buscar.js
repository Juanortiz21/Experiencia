// routes/buscar.js
const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();

// Ruta del archivo JSON compartido con server.js
const archivoJSON = path.join(__dirname, '../db.json');

// Buscar pacientes por nombre o número de documento
router.get('/buscar', (req, res) => {
  const query = req.query.q?.toLowerCase() || '';

  fs.readFile(archivoJSON, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Error al leer datos' });

    let jsonData;
    try {
      jsonData = JSON.parse(data);
    } catch {
      return res.status(500).json({ error: 'Error al parsear JSON' });
    }

    const resultados = jsonData.pacientes.filter(p =>
      p.nombre.toLowerCase().includes(query) ||
      p.documento.numero.includes(query)
    );

    res.json(resultados);
  });
});

module.exports = router;
