// routes/estadisticas.js
const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const archivoJSON = path.join(__dirname, '../db.json');

router.get('/estadisticas', (req, res) => {
  fs.readFile(archivoJSON, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Error al leer los datos' });

    try {
      const { pacientes = [] } = JSON.parse(data);

      const totalPacientes = pacientes.length;
      const edadPromedio = totalPacientes
        ? (pacientes.reduce((s, p) => s + Number(p.edad || 0), 0) / totalPacientes).toFixed(1)
        : 0;

      // Clasificar por edad
      const menores = pacientes.filter(p => p.edad < 18).length;
      const mayores = pacientes.filter(p => p.edad >= 18).length;

      // Contar enfermedades
      const enfermedades = {};
      pacientes.forEach(p => {
        const e = p.enfermedad?.trim() || 'No especificada';
        enfermedades[e] = (enfermedades[e] || 0) + 1;
      });

      // Contar lugares
      const lugares = {};
      pacientes.forEach(p => {
        const l = p.nacimiento?.trim() || 'Desconocido';
        lugares[l] = (lugares[l] || 0) + 1;
      });

      res.json({ totalPacientes, edadPromedio, menores, mayores, enfermedades, lugares });
    } catch (error) {
      res.status(500).json({ error: 'Error al procesar los datos' });
    }
  });
});

module.exports = router;
