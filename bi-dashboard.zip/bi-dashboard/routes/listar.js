const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const archivoJSON = path.join(__dirname, '../db.json');

router.get('/pacientes', (req, res) => {
  fs.readFile(archivoJSON, 'utf8', (err, data) => {
    if (err) {
      console.error('❌ Error al leer db.json:', err);
      return res.status(500).json({ error: 'Error al leer los datos' });
    }

    try {
      const jsonData = JSON.parse(data);
      const lista = jsonData.pacientes.map(p => ({
        id: p.id,
        nombre: p.nombre,
        enfermedad: p.enfermedad,
      }));

      res.json(lista);
    } catch (e) {
      console.error('❌ Error al parsear JSON:', e);
      res.status(500).json({ error: 'Error al procesar los datos' });
    }
  });
});

module.exports = router;
