
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const crypto = require('crypto');

const buscarRouter = require('./routes/buscar.js');
const eliminarRouter = require('./routes/eliminar.js');
const listarRouter = require('./routes/listar.js');
const estadisticasRouter = require('./routes/estadisticas.js');



const app = express();
app.use(express.json());
app.use(cors());

const archivoJSON = path.join(__dirname, 'db.json');

if (!fs.existsSync(archivoJSON)) {
  fs.writeFileSync(archivoJSON, JSON.stringify({ pacientes: [] }, null, 2));
  console.log('🆕 Archivo db.json creado automáticamente.');
}

app.post('/registrar', (req, res) => {
  const datosRecibidos = req.body;

  fs.readFile(archivoJSON, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Error al leer datos' });

    let jsonData = { pacientes: [] };
    try {
      jsonData = JSON.parse(data);
    } catch {
      console.warn('⚠️ Archivo JSON vacío o malformado.');
    }

    const nuevoPaciente = {
      id: crypto.randomUUID(),
      ...datosRecibidos,
    };

    jsonData.pacientes.push(nuevoPaciente);

    fs.writeFile(archivoJSON, JSON.stringify(jsonData, null, 2), err => {
      if (err) return res.status(500).json({ error: 'Error al guardar datos' });
      res.json({ mensaje: 'Paciente registrado con éxito ✅', id: nuevoPaciente.id });
    });
  });
});


app.use('/', buscarRouter);
app.use('/', eliminarRouter);
app.use('/', listarRouter);
app.use('/', estadisticasRouter);



// 🔽 Sirve los archivos del frontend DESPUÉS de las rutas
app.use(express.static(__dirname));

app.listen(3000, () => console.log('✅ Servidor en http://localhost:3000'));
